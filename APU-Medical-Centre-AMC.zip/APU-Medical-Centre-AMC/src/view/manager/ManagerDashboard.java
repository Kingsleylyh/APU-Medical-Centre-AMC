
package view.manager;

import java.awt.*;
import java.io.*;
import java.util.*;
import java.util.List;
import javax.swing.*;
import model.User;


public class ManagerDashboard extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(ManagerDashboard.class.getName());
    private String userId;
    private String userName;

    public ManagerDashboard(User user) {
        this.userId = user.getId();
        this.userName = user.getName();
        initComponents();
        lblWelcome.setText("Hi, " + userName);
    }
    
    public ManagerDashboard() {
    this.userId = "dummyID";
    this.userName = "Demo Manager";
    initComponents();
    lblWelcome.setText("Hi, " + userName);
    }



    public static void buttonGlow(javax.swing.JButton button, java.awt.Color borderColor, java.awt.Color buttonColor) {
        final javax.swing.border.Border originalBorder = button.getBorder();
        final java.awt.Color originalBgColor = button.getBackground();
        final java.awt.Color originalFgColor = button.getForeground();
        
        button.setBorderPainted(true);

        javax.swing.border.Border glowBorder = javax.swing.BorderFactory.createLineBorder(borderColor, 4, true);

        button.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBorder(glowBorder);
                button.setBackground(buttonColor);
                button.setForeground(borderColor);
            }
            
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                button.setBackground(buttonColor.darker());
            }

            @Override
            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBorder(originalBorder);
                button.setBackground(originalBgColor);
                button.setForeground(originalFgColor);
            }
        });
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        lblTitle = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        lblWelcome = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        btnManager = new javax.swing.JButton();
        btnCustomer = new javax.swing.JButton();
        btnStaff = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();
        btnReport = new javax.swing.JButton();
        btnComments = new javax.swing.JButton();
        btnAppointment = new javax.swing.JButton();
        lblManage = new javax.swing.JLabel();
        lblView = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);
        setSize(new java.awt.Dimension(800, 600));

        jPanel2.setBackground(new java.awt.Color(233, 226, 219));
        jPanel2.setForeground(new java.awt.Color(233, 226, 219));
        jPanel2.setPreferredSize(new java.awt.Dimension(800, 600));

        lblTitle.setFont(new java.awt.Font("Garamond", 1, 24)); // NOI18N
        lblTitle.setForeground(new java.awt.Color(153, 124, 93));
        lblTitle.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTitle.setText("Manager Dashboard");

        jPanel3.setBackground(new java.awt.Color(246, 243, 240));

        lblWelcome.setFont(new java.awt.Font("Garamond", 0, 24)); // NOI18N
        lblWelcome.setForeground(new java.awt.Color(37, 61, 85));
        lblWelcome.setText("Hi, ");

        jPanel4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel4.setToolTipText("");

        btnManager.setBackground(new java.awt.Color(166, 124, 0));
        btnManager.setFont(new java.awt.Font("Garamond", 1, 18)); // NOI18N
        btnManager.setForeground(new java.awt.Color(255, 255, 255));
        btnManager.setText("Managers");
        btnManager.setToolTipText("");
        btnManager.setBorder(null);
        btnManager.setBorderPainted(false);
        btnManager.setFocusPainted(false);
        btnManager.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                btnManagerMouseReleased(evt);
            }
        });
        btnManager.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnManagerActionPerformed(evt);
            }
        });

        btnCustomer.setBackground(new java.awt.Color(166, 124, 0));
        btnCustomer.setFont(new java.awt.Font("Garamond", 1, 18)); // NOI18N
        btnCustomer.setForeground(new java.awt.Color(255, 255, 255));
        btnCustomer.setText("Customers");
        btnCustomer.setToolTipText("");
        btnCustomer.setBorder(null);
        btnCustomer.setBorderPainted(false);
        btnCustomer.setFocusPainted(false);
        btnCustomer.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                btnCustomerMouseReleased(evt);
            }
        });
        btnCustomer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCustomerActionPerformed(evt);
            }
        });

        btnStaff.setBackground(new java.awt.Color(166, 124, 0));
        btnStaff.setFont(new java.awt.Font("Garamond", 1, 18)); // NOI18N
        btnStaff.setForeground(new java.awt.Color(255, 255, 255));
        btnStaff.setText("Staffs");
        btnStaff.setToolTipText("");
        btnStaff.setBorder(null);
        btnStaff.setBorderPainted(false);
        btnStaff.setFocusPainted(false);
        btnStaff.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                btnStaffMouseReleased(evt);
            }
        });
        btnStaff.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnStaffActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(70, 70, 70)
                .addComponent(btnManager, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnCustomer, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(135, 135, 135)
                .addComponent(btnStaff, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(71, 71, 71))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnManager, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnCustomer, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnStaff, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(32, Short.MAX_VALUE))
        );

        jPanel5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        btnReport.setBackground(new java.awt.Color(24, 64, 133));
        btnReport.setFont(new java.awt.Font("Garamond", 1, 18)); // NOI18N
        btnReport.setForeground(new java.awt.Color(255, 255, 255));
        btnReport.setText("Analysis");
        btnReport.setBorder(null);
        btnReport.setBorderPainted(false);
        btnReport.setFocusPainted(false);
        btnReport.setPreferredSize(new java.awt.Dimension(190, 28));
        btnReport.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                btnReportMouseReleased(evt);
            }
        });

        btnComments.setBackground(new java.awt.Color(24, 64, 133));
        btnComments.setFont(new java.awt.Font("Garamond", 1, 18)); // NOI18N
        btnComments.setForeground(new java.awt.Color(255, 255, 255));
        btnComments.setText("Feedbacks/Comments");
        btnComments.setBorder(null);
        btnComments.setBorderPainted(false);
        btnComments.setFocusPainted(false);
        btnComments.setPreferredSize(new java.awt.Dimension(190, 28));
        btnComments.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                btnCommentsMouseReleased(evt);
            }
        });

        btnAppointment.setBackground(new java.awt.Color(24, 64, 133));
        btnAppointment.setFont(new java.awt.Font("Garamond", 1, 18)); // NOI18N
        btnAppointment.setForeground(new java.awt.Color(255, 255, 255));
        btnAppointment.setText("Appointments");
        btnAppointment.setBorder(null);
        btnAppointment.setBorderPainted(false);
        btnAppointment.setFocusPainted(false);
        btnAppointment.setMaximumSize(new java.awt.Dimension(190, 28));
        btnAppointment.setMinimumSize(new java.awt.Dimension(190, 28));
        btnAppointment.setPreferredSize(new java.awt.Dimension(190, 28));
        btnAppointment.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                btnAppointmentMouseReleased(evt);
            }
        });
        btnAppointment.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAppointmentActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addGap(39, 39, 39)
                .addComponent(btnAppointment, javax.swing.GroupLayout.PREFERRED_SIZE, 205, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnComments, javax.swing.GroupLayout.PREFERRED_SIZE, 206, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(57, 57, 57)
                .addComponent(btnReport, javax.swing.GroupLayout.PREFERRED_SIZE, 206, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(36, 36, 36))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addContainerGap(25, Short.MAX_VALUE)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnReport, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnComments, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnAppointment, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18))
        );

        lblManage.setFont(new java.awt.Font("Segoe UI Variable", 0, 14)); // NOI18N
        lblManage.setText("Manage");

        lblView.setFont(new java.awt.Font("Segoe UI Variable", 0, 14)); // NOI18N
        lblView.setText("View");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addComponent(lblWelcome, javax.swing.GroupLayout.PREFERRED_SIZE, 298, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(100, 100, 100)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(lblManage)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(lblView)
                        .addContainerGap(869, Short.MAX_VALUE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(81, 81, 81))))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(lblWelcome)
                .addGap(74, 74, 74)
                .addComponent(lblManage)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(82, 82, 82)
                .addComponent(lblView)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(124, Short.MAX_VALUE))
        );

        jPanel4.getAccessibleContext().setAccessibleName("");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(lblTitle)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lblTitle)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, 998, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 657, Short.MAX_VALUE)
        );

        jPanel2.getAccessibleContext().setAccessibleDescription("");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnCommentsMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnCommentsMouseReleased
        FeedbackandCommentList fnc=new FeedbackandCommentList(userId);
        this.setVisible(false);
        fnc.setVisible(true);
        fnc.setLocationRelativeTo(this);
        fnc.setSize(800,600);
    }//GEN-LAST:event_btnCommentsMouseReleased

    private void btnAppointmentMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnAppointmentMouseReleased
        AppointmentList al =new AppointmentList(userId);
        this.setVisible(false);
        al.setVisible(true);
        al.setLocationRelativeTo(this);
        al.setSize(800,600);
    }//GEN-LAST:event_btnAppointmentMouseReleased

    private void btnAppointmentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAppointmentActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnAppointmentActionPerformed

    private void btnReportMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnReportMouseReleased
        Reports r =new Reports(userId);
        this.setVisible(false);
        r.setVisible(true);
        r.setLocationRelativeTo(this);
        r.setSize(800,600);
    }//GEN-LAST:event_btnReportMouseReleased

    private void btnStaffActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnStaffActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnStaffActionPerformed

    private void btnStaffMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnStaffMouseReleased
        StaffList sl =new StaffList(userId);
        this.setVisible(false);
        sl.setVisible(true);
        sl.setLocationRelativeTo(this);
        sl.setSize(800,600);
    }//GEN-LAST:event_btnStaffMouseReleased

    private void btnCustomerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCustomerActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnCustomerActionPerformed

    private void btnCustomerMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnCustomerMouseReleased
        CustomerList cl =new CustomerList(userId);
        this.setVisible(false);
        cl.setVisible(true);
        cl.setLocationRelativeTo(this);
        cl.setSize(800,600);
    }//GEN-LAST:event_btnCustomerMouseReleased

    private void btnManagerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnManagerActionPerformed

    }//GEN-LAST:event_btnManagerActionPerformed

    private void btnManagerMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnManagerMouseReleased
        ManagerList ml =new ManagerList(userId);
        this.setVisible(false);
        ml.setVisible(true);
        ml.setLocationRelativeTo(this);
        ml.setSize(800,600);
    }//GEN-LAST:event_btnManagerMouseReleased

        public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new ManagerDashboard().setVisible(true));
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAppointment;
    private javax.swing.JButton btnComments;
    private javax.swing.JButton btnCustomer;
    private javax.swing.JButton btnManager;
    private javax.swing.JButton btnReport;
    private javax.swing.JButton btnStaff;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JLabel lblManage;
    private javax.swing.JLabel lblTitle;
    private javax.swing.JLabel lblView;
    private javax.swing.JLabel lblWelcome;
    // End of variables declaration//GEN-END:variables
}
