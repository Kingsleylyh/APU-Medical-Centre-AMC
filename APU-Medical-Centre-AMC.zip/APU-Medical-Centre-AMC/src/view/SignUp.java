/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package view;
import model.UserDatabase;
import model.Role;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.logging.Logger;

public class SignUp extends javax.swing.JFrame {
    private static final Logger logger = Logger.getLogger(SignUp.class.getName());
    private Role selectedRole;

    public SignUp(Role role) {
        initComponents();
        this.selectedRole = role;
        populateRoleCombo(role);
    }

    private void populateRoleCombo(Role role) {
        cmbRole.removeAllItems();
        cmbRole.addItem(role.name()); // only Manager
        cmbRole.setSelectedIndex(0);
        cmbRole.setEnabled(false); // read-only
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        lblSignUp = new java.awt.Label();
        lblUsername = new java.awt.Label();
        txtUsername = new javax.swing.JTextField();
        txtPassword = new javax.swing.JTextField();
        lblPassword = new java.awt.Label();
        txtEmail = new javax.swing.JTextField();
        lblEmail = new java.awt.Label();
        txtPhone = new javax.swing.JTextField();
        lblPhone = new java.awt.Label();
        txtNRIC = new javax.swing.JTextField();
        lblNRIC = new java.awt.Label();
        btnCancel = new javax.swing.JButton();
        btnRegister = new javax.swing.JButton();
        lblRole = new java.awt.Label();
        cldDOB = new com.toedter.calendar.JDateChooser();
        lblDOB = new java.awt.Label();
        cmbRole = new javax.swing.JComboBox<>();
        txtName = new javax.swing.JTextField();
        lblName = new java.awt.Label();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 204));
        jPanel1.setPreferredSize(new java.awt.Dimension(800, 600));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblSignUp.setFont(new java.awt.Font("Lucida Calligraphy", 0, 48)); // NOI18N
        lblSignUp.setForeground(new java.awt.Color(0, 0, 0));
        lblSignUp.setText("Sign Up");
        jPanel1.add(lblSignUp, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 0, -1, 88));

        lblUsername.setFont(new java.awt.Font("Eras Medium ITC", 0, 18)); // NOI18N
        lblUsername.setText("Username :");
        jPanel1.add(lblUsername, new org.netbeans.lib.awtextra.AbsoluteConstraints(186, 144, -1, -1));

        txtUsername.setToolTipText("");
        jPanel1.add(txtUsername, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 147, 347, -1));

        txtPassword.setToolTipText("");
        jPanel1.add(txtPassword, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 190, 347, -1));

        lblPassword.setFont(new java.awt.Font("Eras Medium ITC", 0, 18)); // NOI18N
        lblPassword.setText("Password :");
        jPanel1.add(lblPassword, new org.netbeans.lib.awtextra.AbsoluteConstraints(186, 187, -1, -1));

        txtEmail.setToolTipText("");
        jPanel1.add(txtEmail, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 233, 347, -1));

        lblEmail.setFont(new java.awt.Font("Eras Medium ITC", 0, 18)); // NOI18N
        lblEmail.setText("Email :");
        jPanel1.add(lblEmail, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 230, -1, -1));

        txtPhone.setToolTipText("");
        jPanel1.add(txtPhone, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 276, 347, -1));

        lblPhone.setFont(new java.awt.Font("Eras Medium ITC", 0, 18)); // NOI18N
        lblPhone.setText("Phone :");
        jPanel1.add(lblPhone, new org.netbeans.lib.awtextra.AbsoluteConstraints(211, 273, -1, -1));

        txtNRIC.setToolTipText("");
        jPanel1.add(txtNRIC, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 311, 347, -1));

        lblNRIC.setFont(new java.awt.Font("Eras Medium ITC", 0, 18)); // NOI18N
        lblNRIC.setText("NRIC :");
        jPanel1.add(lblNRIC, new org.netbeans.lib.awtextra.AbsoluteConstraints(221, 308, -1, -1));

        btnCancel.setBackground(new java.awt.Color(24, 64, 133));
        btnCancel.setForeground(new java.awt.Color(255, 255, 255));
        btnCancel.setText("Cancel");
        btnCancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelActionPerformed(evt);
            }
        });
        jPanel1.add(btnCancel, new org.netbeans.lib.awtextra.AbsoluteConstraints(476, 535, 189, 35));

        btnRegister.setBackground(new java.awt.Color(24, 64, 133));
        btnRegister.setForeground(new java.awt.Color(255, 255, 255));
        btnRegister.setText("Register");
        btnRegister.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRegisterActionPerformed(evt);
            }
        });
        jPanel1.add(btnRegister, new org.netbeans.lib.awtextra.AbsoluteConstraints(186, 535, 189, 35));

        lblRole.setFont(new java.awt.Font("Eras Medium ITC", 0, 18)); // NOI18N
        lblRole.setText("Role :");
        jPanel1.add(lblRole, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 380, 50, 30));
        lblRole.getAccessibleContext().setAccessibleName("");

        jPanel1.add(cldDOB, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 349, 347, -1));

        lblDOB.setFont(new java.awt.Font("Eras Medium ITC", 0, 18)); // NOI18N
        lblDOB.setText("DOB :");
        jPanel1.add(lblDOB, new org.netbeans.lib.awtextra.AbsoluteConstraints(222, 346, -1, -1));

        cmbRole.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jPanel1.add(cmbRole, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 382, 350, 30));

        txtName.setToolTipText("");
        jPanel1.add(txtName, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 110, 347, -1));

        lblName.setFont(new java.awt.Font("Eras Medium ITC", 0, 18)); // NOI18N
        lblName.setText("Name :");
        jPanel1.add(lblName, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 110, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnCancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelActionPerformed
            new Login().setVisible(true);
            this.dispose();
    }//GEN-LAST:event_btnCancelActionPerformed

    private void btnRegisterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegisterActionPerformed
        String username = txtUsername.getText().trim();
        String name = txtName.getText().trim();
        String password = txtPassword.getText().trim();
        String email = txtEmail.getText().trim();
        String phone = txtPhone.getText().trim();
        String nric = txtNRIC.getText().trim();
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        String dob = cldDOB.getDate() != null ? df.format(cldDOB.getDate()) : "";
        String role = cmbRole.getSelectedItem().toString();

        if (username.isEmpty() || password.isEmpty() || email.isEmpty() || phone.isEmpty() || nric.isEmpty() || dob.isEmpty()) {
            javax.swing.JOptionPane.showMessageDialog(this, "All fields are required!", "Warning", javax.swing.JOptionPane.WARNING_MESSAGE);
            return;
        }

        if (UserDatabase.usernameExists(username)) {
            javax.swing.JOptionPane.showMessageDialog(this, "Username already exists!", "Error", javax.swing.JOptionPane.ERROR_MESSAGE);
            return;
        }

    try {
        String id = UserDatabase.generateUserId();
        UserDatabase.saveUser(id, username, name, password, email, phone, nric, dob, role);
        javax.swing.JOptionPane.showMessageDialog(this, "Registration successful! Your ID is " + id, "Success", javax.swing.JOptionPane.INFORMATION_MESSAGE);
        new Login().setVisible(true);
        this.dispose();
    } catch (Exception ex) {
        javax.swing.JOptionPane.showMessageDialog(this,
                "Error saving user: " + ex.getMessage(),
                "Error", javax.swing.JOptionPane.ERROR_MESSAGE);
    }
    }//GEN-LAST:event_btnRegisterActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCancel;
    private javax.swing.JButton btnRegister;
    private com.toedter.calendar.JDateChooser cldDOB;
    private javax.swing.JComboBox<String> cmbRole;
    private javax.swing.JPanel jPanel1;
    private java.awt.Label lblDOB;
    private java.awt.Label lblEmail;
    private java.awt.Label lblNRIC;
    private java.awt.Label lblName;
    private java.awt.Label lblPassword;
    private java.awt.Label lblPhone;
    private java.awt.Label lblRole;
    private java.awt.Label lblSignUp;
    private java.awt.Label lblUsername;
    private javax.swing.JTextField txtEmail;
    private javax.swing.JTextField txtNRIC;
    private javax.swing.JTextField txtName;
    private javax.swing.JTextField txtPassword;
    private javax.swing.JTextField txtPhone;
    private javax.swing.JTextField txtUsername;
    // End of variables declaration//GEN-END:variables
}
