/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package presenter.staff;

/**
 *
 * @author TAI KOK WAI
 */
public interface IPaymentHandler {
    void showSummary(String appointmentId);
    void processPayment(String appointmentId, String method);
    
}
