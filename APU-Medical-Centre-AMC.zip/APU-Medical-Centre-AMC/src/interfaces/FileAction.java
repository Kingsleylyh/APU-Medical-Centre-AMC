package interfaces;

public interface FileAction {
	void createFile();
	void getDataFromFile();
	void saveDataToFile();
}
