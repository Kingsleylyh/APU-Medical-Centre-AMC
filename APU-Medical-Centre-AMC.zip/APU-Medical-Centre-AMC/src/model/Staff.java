/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

public class Staff extends User {
    private String position;

    public Staff(String id, String username, String password, String name,
                 String email, int phone, int NRIC, String position) {
        super(id, username, password, name, email, phone, NRIC, Role.STAFF);
        this.position = position;
    }

    @Override
    public Role getRole() { return Role.STAFF; }

    @Override
    public String getExtraInfo() { return position; }

    public String getPosition() { return position; }
    public void setPosition(String position) { this.position = position; }
}
