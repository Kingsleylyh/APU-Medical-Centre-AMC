package model;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public abstract class User {

    protected String id;
    protected String username;
    protected String password;  
    protected String name;
    protected String email;
    protected int phone;
    protected int NRIC;
    protected static boolean isLogin;
    protected Role role;

    public User(String id, String username, String password, String name,
                String email, int phone, int NRIC, Role role) {
        this.id = id;
        this.username = username;
        this.password = hashPassword(password);
        this.name = name;
        this.email = email;
        this.phone = phone;
        this.NRIC = NRIC;
        this.role = role;
    }

    public abstract Role getRole();

    public abstract String getExtraInfo(); 

    public static String hashPassword(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hashedBytes = md.digest(password.getBytes());
            StringBuilder sb = new StringBuilder();
            for (byte b : hashedBytes) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("Error hashing password", e);
        }
    }
    
        public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getPhone() {
        return phone;
    }

    public void setPhone(int phone) {
        this.phone = phone;
    }

    public int getNRIC() {
        return NRIC;
    }

    public void setNRIC(int NRIC) {
        this.NRIC = NRIC;
    }

    public static boolean isIsLogin() { return isLogin; }
    public static void setIsLogin(boolean isLogin) { User.isLogin = isLogin; }
}
