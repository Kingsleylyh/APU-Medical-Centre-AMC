package model;

public class Manager extends User {
    public Manager(String id, String username, String password, String name, String email, int phone, int nric) {
        super(id, username, password, name, email, phone, nric, Role.MANAGER);
    }

    @Override
    public Role getRole() {
        return Role.MANAGER;
    }

    @Override
    public String getExtraInfo() {
        return "-,-,-"; 
    }
}
