    package model;

    public enum Role {
            MANAGER, STAFF, DOCTOR, CUSTOMER
    }
