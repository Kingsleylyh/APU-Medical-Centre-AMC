/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

public class Doctor extends User {
    private String specialization;

    public Doctor(String id, String username, String password, String name,
                  String email, int phone, int NRIC, String specialization) {
        super(id, username, password, name, email, phone, NRIC, Role.DOCTOR);
        this.specialization = specialization;
    }

    @Override
    public Role getRole() { return Role.DOCTOR; }

    @Override
    public String getExtraInfo() { return specialization; }

    public String getSpecialization() { return specialization; }
    public void setSpecialization(String specialization) { this.specialization = specialization; }
}
