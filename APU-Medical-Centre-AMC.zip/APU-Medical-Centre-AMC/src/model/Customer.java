package model;

public class Customer extends User {
    private String address;
    private String emergencyContact;

    public Customer(String id, String username, String password, String name,
                    String email, int phone, int NRIC, String address, String emergencyContact) {
        super(id, username, password, name, email, phone, NRIC, Role.CUSTOMER);
        this.address = address;
        this.emergencyContact = emergencyContact;
    }

    @Override
    public Role getRole() { return Role.CUSTOMER; }

    @Override
    public String getExtraInfo() { return address + "," + emergencyContact; }

    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }
    public String getEmergencyContact() { return emergencyContact; }
    public void setEmergencyContact(String emergencyContact) { this.emergencyContact = emergencyContact; }
}
