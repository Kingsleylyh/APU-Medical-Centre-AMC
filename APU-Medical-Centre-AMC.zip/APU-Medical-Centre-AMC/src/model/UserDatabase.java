package model;

import java.io.*;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class UserDatabase {
    private static final String FILE_PATH = "database/user.txt";

    public static void ensureFileExists() {
        File file = new File(FILE_PATH);
        if (!file.exists()) {
            file.getParentFile().mkdirs();
            try (PrintWriter pw = new PrintWriter(new FileWriter(file))) {
                pw.println("userId|username|password|name|email|phone|NRIC|role|extraInfo");
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    /** SHA-256 password hash */
    public static String hashPassword(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hash = md.digest(password.getBytes());
            StringBuilder sb = new StringBuilder();
            for (byte b : hash) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("Hash error", e);
        }
    }

    /** Add user with hashed password */
    public static boolean saveUser(User user) {
        if (usernameExists(user.getUsername()) || isIdTaken(user.getId())) {
            return false;
        }

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_PATH, true))) {
            writer.write(user.getId() + "," +
                         user.getUsername() + "," +
                         hashPassword(user.getPassword()) + "," +   // hash here
                         user.getName() + "," +
                         user.getEmail() + "," +
                         user.getPhone() + "," +
                         user.getNRIC() + "," +
                         user.getRole() + "," +
                         (user instanceof Doctor ? ((Doctor)user).getSpecialization() : "-") + "," +
                         (user instanceof Customer ? ((Customer)user).getAddress() : "-") + "," +
                         (user instanceof Customer ? ((Customer)user).getEmergencyContact() : "-") + "," +
                         (user instanceof Staff ? ((Staff)user).getPosition() : "-")
            );
            writer.newLine();
            return true;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }

    /** Generate unique UserID */
    public static String generateUserId() {
        int count = 0;
        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_PATH))) {
            reader.readLine(); // skip header
            while (reader.readLine() != null) count++;
        } catch (IOException e) { }
        return "U" + String.format("%03d", count + 1);
    }

    /** Verify login using hashed password */
    public static User verifyLogin(String username, String plainPassword) {
        File file = new File(FILE_PATH);
        if (!file.exists()) {
            System.out.println("User file not found.");
            return null;
        }

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            String hashedInput = User.hashPassword(plainPassword);

            while ((line = br.readLine()) != null) {
                if (line.trim().isEmpty()) continue;

                String[] parts = line.split("\\|");
                if (parts.length < 8) continue;

                String fileUserId = parts[0].trim();
                String fileUsername = parts[1].trim();
                String fileHashedPassword = parts[2].trim();
                String name = parts[3].trim();
                String email = parts[4].trim();
                int phone = Integer.parseInt(parts[5].trim());
                int nric = Integer.parseInt(parts[6].trim());
                String roleStr = parts[7].trim().toUpperCase();

                if (fileUsername.equalsIgnoreCase(username)) {
                    // username found → check password
                    if (fileHashedPassword.equals(hashedInput)) {
                        Role role = Role.valueOf(roleStr);
                        // Create a generic User object
                        return new User(fileUserId, fileUsername, fileHashedPassword,
                                        name, email, phone, nric, role) {
                            @Override
                            public Role getRole() { return role; }

                            @Override
                            public String getExtraInfo() { return (parts.length > 8) ? parts[8] : ""; }
                        };
                    } else {
                        return null; // password mismatch
                    }
                }
            }
        } catch (IOException | NumberFormatException e) {
            e.printStackTrace();
        }
        return null; // not found
    }

    /** Check if username already exists */
    public static boolean usernameExists(String username) {
        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_PATH))) {
            reader.readLine(); // skip header
            String line;
            while ((line = reader.readLine()) != null) {
                String[] data = line.split(",");
                if (data.length >= 2 && data[1].equalsIgnoreCase(username)) return true;
            }
        } catch (IOException e) { }
        return false;
    }

    /** Check if ID already exists */
    public static boolean isIdTaken(String id) {
        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_PATH))) {
            reader.readLine(); // skip header
            String line;
            while ((line = reader.readLine()) != null) {
                String[] data = line.split(",");
                if (data.length >= 1 && data[0].equals(id)) return true;
            }
        } catch (IOException e) { }
        return false;
    }

    public static void saveUser(String id, String username, String name, String password, String email, String phone, String nric, String dob, String role) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
